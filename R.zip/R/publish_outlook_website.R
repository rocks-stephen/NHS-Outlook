# Build the static website from the outputs produced by the publication pipeline.
# The homepage remains the NHS Outlook itself; web-only controls are added here.

source("R/utils.R")

project_root <- getwd()
html_source_dir <- file.path(project_root, "output", "releases")
publication_root <- file.path(project_root, "output", "publication")
site_dir <- file.path(project_root, "publication_site")
overview_manifest_path <- file.path(
  project_root, "output", "performance", "overview_manifest.csv"
)

required_directories <- c(html_source_dir, publication_root)
missing_directories <- required_directories[!dir.exists(required_directories)]
if (length(missing_directories)) {
  stop("Website inputs are missing: ", paste(missing_directories, collapse = ", "), ".")
}
if (!file.exists(overview_manifest_path)) {
  stop("Website build requires ", overview_manifest_path, ". Run script 17 first.")
}

overview_manifest <- data.table::fread(overview_manifest_path, encoding = "UTF-8")
assert_columns(
  overview_manifest,
  c("issue_date", "publication_mode", "publication_status"),
  "performance overview manifest"
)
if (nrow(overview_manifest) != 1L ||
    !overview_manifest$publication_mode[1L] %in% c("forecast", "outturn")) {
  stop("The public website requires one forecast or outturn overview manifest.")
}
publication_mode <- overview_manifest$publication_mode[1L]
release_date <- as.Date(overview_manifest$issue_date[1L])
if (is.na(release_date)) stop("Overview manifest contains an invalid issue date.")
if (overview_manifest$publication_status[1L] != "pilot") {
  stop("This publication is configured as a pilot but the manifest is not marked pilot.")
}
issue_day <- format(release_date, "%Y-%m-%d")
bundle_dir <- file.path(publication_root, issue_day, publication_mode)
if (!dir.exists(bundle_dir)) {
  stop("Publication bundle folder not found: ", bundle_dir, ".")
}

metric_config <- data.table::fread(
  file.path(project_root, "config", "performance_metrics.csv"),
  encoding = "UTF-8"
)
metric_config[, active := parse_logical_strict(active)]
rows_path <- file.path(
  project_root, "output", "performance",
  if (publication_mode == "forecast") "overview_metric_rows.csv" else "outturn_metric_rows.csv"
)
if (!file.exists(rows_path)) stop("Website metric rows not found: ", rows_path, ".")
published_rows <- data.table::fread(rows_path, encoding = "UTF-8")
assert_columns(
  published_rows, c("metric_id", "display_order", "display_name", "deep_dive_file"),
  "website metric rows"
)
detail_tbl <- published_rows[, .(
  metric_id, display_order, label = display_name, file = deep_dive_file
)][order(display_order)]
expected_metric_ids <- c(
  "ae4h_all", "ambulance_cat2", "rtt_18w", "diagnostics_6w",
  "cancer_62d", "ucr_2h", "community_18w", "talking_therapies_6w"
)
if (nrow(detail_tbl) != 8L ||
    !identical(detail_tbl$metric_id, expected_metric_ids)) {
  stop(
    "Website publication requires the eight configured headline indicators in ",
    "their expected order; found: ", paste(detail_tbl$metric_id, collapse = ", "), "."
  )
}
expected_suffix <- if (publication_mode == "forecast") {
  "-outlook-latest.html"
} else {
  "-outturn-latest.html"
}
if (!all(endsWith(detail_tbl$file, expected_suffix))) {
  stop("Indicator detail files do not match the active publication mode.")
}
if (detail_tbl[metric_id == "community_18w", file] ==
    detail_tbl[metric_id == "rtt_18w", file]) {
  stop("Community 18-week and RTT detailed outputs are not distinctly mapped.")
}
detail_tbl[, source_file := file.path(html_source_dir, file)]
missing_details <- detail_tbl[!file.exists(source_file), file]
if (length(missing_details)) {
  stop(
    "All eight current detailed HTML files are required; missing: ",
    paste(missing_details, collapse = ", "), "."
  )
}

main_filename <- if (publication_mode == "forecast") {
  "nhs-performance-outlook-forecast-latest.html"
} else {
  "nhs-performance-outturn-latest.html"
}
main_html <- file.path(html_source_dir, main_filename)
if (!file.exists(main_html)) {
  stop("Current main NHS Outlook HTML was not found: ", main_html, ".")
}
main_latest_alias <- if (publication_mode == "forecast") {
  file.path(html_source_dir, "nhs-performance-outlook-latest.html")
} else {
  character()
}
if (length(main_latest_alias) && !file.exists(main_latest_alias)) {
  stop("Current main NHS Outlook latest alias was not found: ", main_latest_alias, ".")
}

dir.create(site_dir, recursive = TRUE, showWarnings = FALSE)
forecast_asset_dir <- file.path(site_dir, "forecasts")
if (dir.exists(forecast_asset_dir)) {
  unlink(forecast_asset_dir, recursive = TRUE, force = TRUE)
}
pdf_site_dir <- file.path(forecast_asset_dir, issue_day)
dir.create(pdf_site_dir, recursive = TRUE, showWarnings = FALSE)

provider_watch_files <- character()
if (publication_mode == "outturn") {
  provider_manifest_path <- file.path(
    project_root, "output", "performance", "outturn_provider_watch_manifest.csv"
  )
  provider_manifest <- data.table::fread(provider_manifest_path, encoding = "UTF-8")
  assert_columns(provider_manifest, "output_file", "outturn provider-watch manifest")
  provider_watch_files <- file.path(html_source_dir, provider_manifest$output_file)
}
html_to_copy <- unique(c(main_html, main_latest_alias, detail_tbl$source_file,
                         provider_watch_files))
copied_html <- file.copy(
  html_to_copy,
  file.path(site_dir, basename(html_to_copy)),
  overwrite = TRUE
)
if (!all(copied_html)) {
  stop("One or more current publication HTML files could not be copied.")
}

pdf_sources <- list.files(
  bundle_dir, pattern = "[.]pdf$", full.names = TRUE, ignore.case = TRUE
)
if (!length(pdf_sources)) stop("The publication bundle contains no PDFs.")
copied_pdf <- file.copy(
  pdf_sources,
  file.path(pdf_site_dir, basename(pdf_sources)),
  overwrite = TRUE
)
if (!all(copied_pdf)) stop("One or more publication PDFs could not be copied.")

main_pdf_pattern <- if (publication_mode == "forecast") {
  "^nhs-performance-outlook-forecast-.*[.]pdf$"
} else {
  "^nhs-performance-outturn-.*[.]pdf$"
}
main_pdf <- pdf_sources[grepl(main_pdf_pattern, basename(pdf_sources), ignore.case = TRUE)]
if (!length(main_pdf)) {
  stop("The publication bundle has no main NHS Performance Outlook PDF.")
}
dated_main_pdf <- main_pdf[grepl(issue_day, basename(main_pdf), fixed = TRUE)]
main_pdf <- if (length(dated_main_pdf)) dated_main_pdf[1L] else main_pdf[1L]
main_pdf_path <- gsub(
  "\\\\", "/",
  file.path("forecasts", issue_day, basename(main_pdf))
)

html <- paste(
  readLines(main_html, warn = FALSE, encoding = "UTF-8"),
  collapse = "\n"
)
if (!grepl("Pilot", html, fixed = TRUE)) {
  stop("Main NHS Outlook HTML is not marked Pilot; rebuild script 17.")
}
for (detail_file in detail_tbl$file) {
  link <- paste0('href="', detail_file, '"')
  if (!grepl(link, html, fixed = TRUE)) {
    stop("Main NHS Outlook is missing its indicator link to ", detail_file, ".")
  }
}

extra_css <- paste0(
  "\n    .outlook-actions{display:flex;gap:10px;align-items:center;",
  "margin:13px 0 2px;flex-wrap:wrap}",
  ".button-link{display:inline-block;padding:8px 12px;border:1px solid ",
  "var(--brand);border-radius:3px;color:var(--brand);text-decoration:none;",
  "font-size:9px;font-weight:800;letter-spacing:.04em}",
  ".button-link.primary{background:var(--brand);color:#fff}",
  "@media print{.outlook-actions{display:none!important}}\n"
)
html <- sub("</style>", paste0(extra_css, "</style>"), html, fixed = TRUE)
actions <- paste0(
  '<div class="outlook-actions">',
  '<a class="button-link primary" href="', main_pdf_path,
  '">Download this edition as PDF</a></div>'
)
html <- sub("</table>", paste0("</table>\n", actions), html, fixed = TRUE)

if (grepl('id="detailed-forecasts"', html, fixed = TRUE)) {
  stop("The homepage must not contain a second Detailed forecasts section.")
}
index_file <- file.path(site_dir, "index.html")
writeLines(html, index_file, useBytes = TRUE)
file.create(file.path(site_dir, ".nojekyll"), showWarnings = FALSE)

website_manifest <- data.table::rbindlist(list(
  data.table::data.table(
    artifact_role = "homepage", metric_id = NA_character_,
    relative_path = "index.html"
  ),
  detail_tbl[, .(
    artifact_role = "indicator_detail", metric_id,
    relative_path = file
  )],
  if (length(provider_watch_files)) data.table::data.table(
    artifact_role = "provider_watch",
    metric_id = NA_character_,
    relative_path = basename(provider_watch_files)
  ) else NULL,
  data.table::data.table(
    artifact_role = "pdf", metric_id = NA_character_,
    relative_path = gsub(
      "\\\\", "/",
      file.path("forecasts", issue_day, basename(pdf_sources))
    )
  )
), use.names = TRUE, fill = TRUE)
website_manifest[, `:=`(
  issue_date = issue_day,
  exists = file.exists(file.path(site_dir, relative_path))
)]
data.table::fwrite(
  website_manifest, file.path(site_dir, "website_manifest.csv")
)
if (any(!website_manifest$exists)) {
  stop("Website manifest contains one or more missing files.")
}

# GitHub Pages for this repository is configured to serve the root of the main
# branch. Keep publication_site as the canonical assembled website, then mirror
# only its current public artifacts into the repository root. This avoids a
# second hand-maintained publishing script and makes one pipeline run sufficient
# before the normal git commit and push.
root_html_sources <- unique(c(
  index_file,
  file.path(site_dir, basename(html_to_copy))
))
root_support_sources <- c(
  file.path(site_dir, ".nojekyll"),
  file.path(site_dir, "website_manifest.csv")
)
root_file_sources <- c(root_html_sources, root_support_sources)
root_file_destinations <- file.path(
  project_root, basename(root_file_sources)
)
root_copied <- file.copy(
  root_file_sources, root_file_destinations, overwrite = TRUE
)
if (!all(root_copied)) {
  stop("One or more current website files could not be mirrored to the repository root.")
}

root_pdf_dir <- file.path(project_root, "forecasts", issue_day)
dir.create(root_pdf_dir, recursive = TRUE, showWarnings = FALSE)
root_pdf_destinations <- file.path(root_pdf_dir, basename(pdf_sources))
root_pdf_copied <- file.copy(
  file.path(pdf_site_dir, basename(pdf_sources)),
  root_pdf_destinations,
  overwrite = TRUE
)
if (!all(root_pdf_copied)) {
  stop("One or more current PDFs could not be mirrored to the repository root.")
}

copied_sources <- c(
  root_file_sources,
  file.path(pdf_site_dir, basename(pdf_sources))
)
copied_destinations <- c(
  root_file_destinations,
  root_pdf_destinations
)
copy_matches <- unname(tools::md5sum(copied_sources)) ==
  unname(tools::md5sum(copied_destinations))
if (anyNA(copy_matches) || !all(copy_matches)) {
  stop("Repository-root website mirror failed its byte-for-byte verification.")
}

message(
  "NHS Outlook website built at ", index_file, " with eight detailed HTML ",
  "links and ", length(pdf_sources), " PDF(s) under forecasts/", issue_day,
  "/. Current public artifacts were also verified in the repository root for ",
  "GitHub Pages."
)
if (isTRUE(getOption("nhs.outlook.open_website", interactive()))) {
  utils::browseURL(normalizePath(index_file, winslash = "/"))
}
